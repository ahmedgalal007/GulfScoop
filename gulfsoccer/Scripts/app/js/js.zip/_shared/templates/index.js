define(["require", "exports", "_shared/templates/MdbUI"], function (require, exports, MdbUI_1) {
    "use strict";
    exports.__esModule = true;
    exports["default"] = MdbUI_1.MdbGridUI;
});
//# sourceMappingURL=index.js.map