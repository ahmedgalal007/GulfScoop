/// <reference path="../../../../typings/jquery/jquery.d.ts" />
/// <reference path="../../../../typings/kendo/kendo.all.d.ts" />
/// <amd-dependency path="Scripts/app/lib/kendo.ui.core.min" >
//# sourceMappingURL=app.js.map